# schoology Export RC.2
format csv gradebooks from a schoology export in to a excel file
